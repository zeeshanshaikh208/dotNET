using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MovieApp.Entities;
using MovieApp.Repository;

namespace MovieApp.Pages.Movies
{
    public class VoteModel : PageModel
    {
        public Guid Id { get; set; }
        [BindProperty]
        public Guid UserId { get; set; }

        [BindProperty]
        public string Username { get; set; }

        [BindProperty]
        public UserMovies NeWUserMovies { get; set; }

        private readonly ICommonTask commonTask;

        public VoteModel(ICommonTask commonTask)
        {
            this.commonTask = commonTask;
        }
    
       
        public void OnGet(Guid? id, Guid? userid)
        {
            this.Id = id.Value;
            this.UserId = userid.Value;
            this.Username = Movie.GetMovieNameById(commonTask.GetConnection(),id.Value);
        }

        public IActionResult OnPost()
        {
            var voted = UserMovies.IsVoted(commonTask.GetConnection(), NeWUserMovies);
            if (voted)
            {
                UserMovies.VoteExisting(commonTask.GetConnection(), NeWUserMovies);
            }
            else
            {
                UserMovies.VoteNew(commonTask.GetConnection(), NeWUserMovies);
            }
            //UserMovies.AddVotes(commonTask.GetConnection(), NeWUserMovies);
            //UserDetails = Entities.User.GetUserDetails(commonTask.GetConnection(), this.UserId);
            return Redirect("/Users/Summary?userId="+UserId.ToString());
        }
    }
}
