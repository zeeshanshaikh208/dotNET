using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MovieApp.Entities;
using MovieApp.Repository;

namespace MovieApp.Pages.Movies
{
    public class VoteListModel : PageModel
    {
        public IEnumerable<Movie> MovieList { get; set; }

        public Guid? UserKey { get; set; }


        private readonly ICommonTask commonTask;
        public VoteListModel(ICommonTask commonTask)
        {
            this.commonTask = commonTask;
        }
        
        public void OnGet(Guid? userid)
        {
                this.UserKey = userid.Value;
                MovieList = Movie.GetMovieRating(commonTask.GetConnection());
        }
    }
}
