using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MovieApp.Entities;
using MovieApp.Repository;

namespace MovieApp.Pages.Users
{
    public class SummaryModel : PageModel
    {
        public string UserName { get; set; }
        public Guid? UserId { get; set; }
        public IEnumerable<User> UserSummary { get; set; }


        private readonly ICommonTask commonTask;
        public SummaryModel(ICommonTask commonTask)
        {
            this.commonTask = commonTask;
        }

        public void OnGet(Guid? userId)
        {
            this.UserId = userId;
            this.UserSummary = Entities.User.GetUserDetails(commonTask.GetConnection(), userId.Value);
            this.UserName = Entities.User.GetUserNameById(commonTask.GetConnection(), userId.Value);
        }
    }
}
