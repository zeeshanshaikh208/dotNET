using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MovieApp.Entities;
using MovieApp.Repository;

namespace MovieApp.Pages.Users
{
    public class LoginModel : PageModel
    {
        public IEnumerable<User> UserList { get; set; }

        [BindProperty]
        public User NewUser { get; set; }


        private readonly ICommonTask commonTask;
        public LoginModel(ICommonTask commonTask)
        {
            this.commonTask = commonTask;
        }

        public void OnGet()
        {
            UserList = Entities.User.GetUsers(commonTask.GetConnection());
        }

        public IActionResult OnPostLoginUser()
        {
            var isUser = Entities.User.LoginUser(commonTask.GetConnection(), NewUser);
            if (isUser == false)
            {
                return Redirect("/Users/Register");
            }
            else
            {
                var @userId = Entities.User.GetUserId(commonTask.GetConnection(), NewUser);
                return Redirect("/Movies/VoteList?userid=" + @userId.ToString());
            }

        }
        /* 
           public IActionResult OnPostLoginUser()
           {
               var userId = Entities.User.GetUserId(commonTask.GetConnection(), NewUser);
               if (userId==null)
               {

                 //  Entities.User.RegisterUser(commonTask.GetConnection(), NewUser);
                   return Redirect("/Users/Register");
               }
               else
               {
                   return Redirect("/Movies/Index?userid="+@userId.ToString());
               }

           }
        */

    }
}
