using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MovieApp.Entities;
using MovieApp.Repository;

namespace MovieApp.Pages.Users
{
    public class RegisterModel : PageModel
    {
        private readonly ICommonTask commonTask;

        public RegisterModel(ICommonTask commonTask)
        {
            this.commonTask = commonTask;
        }

         [BindProperty]
        public User user { get; set; }
        public void OnGet()
        {
           
        }
        public IActionResult OnPostRegisterUser()
        {
            var userId = Entities.User.GetUserId(commonTask.GetConnection(), user);
            if (userId != null)
            {

                Entities.User.RegisterUser(commonTask.GetConnection(), user);
                var newUserId = Entities.User.GetUserId(commonTask.GetConnection(), user);
                return Redirect("/Movies/VoteList?userid=" + @newUserId.ToString());
            }
            else
            {
                return RedirectToPage("/Index");
            }
        }


       
    }
}
