﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace MovieApp.Entities
{
    public class UserMovies
    {
        public Guid Id { get; set; }

        public Guid UserId { get; set; }

        public Guid MovieId { get; set; }

        public int Rating { get; set; }

        public bool Active { get; set; }

        public string LastUpdatedBy { get; set; }

        public DateTime LastupdatedOn { get; set; }


        public static void AddVotesTrigger(UserMovies userMovies,string connectionString)
        {
            var connection = new SqlConnection(connectionString);
            connection.Open();
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("@UserId", userMovies.MovieId);
            parameters.Add("@MovieId", userMovies.MovieId);
            parameters.Add("@Rating", userMovies.Rating);
            connection.Execute("user_rating", parameters, commandType: CommandType.StoredProcedure);
        }


        public static void AddVotes(string connectionString,UserMovies userMovies)
        {
            var connection = new SqlConnection(connectionString);
            connection.Open();

            // var query = @"INSERT INTO UserMovies (Id,UserId,MovieId,Rating) VALUES (newid(),@UserId,@MovieId,@Rating)";
            var query = @"IF EXISTS(SELECT * FROM UserMovies WHERE UserId = @UserId AND MovieId = @MovieId)BEGIN UPDATE UserMovies SET Rating = @Rating WHERE UserId = @UserId AND MovieId = @MovieId END ELSE BEGIN INSERT INTO UserMovies (Id,UserId,MovieId,Rating) VALUES (newid(),@UserId,@MovieId,@Rating) END";
            connection.QueryFirstOrDefault(query, new { userMovies.UserId, userMovies.MovieId, userMovies.Rating });
           // connection.Execute(query, userMovies);
           
        }


        public static bool IsVoted(string connectionString, UserMovies userMovies)
        {
            var connection = new SqlConnection(connectionString);
            connection.Open();
            return connection.QueryFirstOrDefault<bool>(@"SELECT 1 FROM UserMovies WHERE UserId = @UserId AND MovieId = @MovieId",new {userMovies.UserId,userMovies.MovieId });
        }
        
        public static void VoteNew(string connectionString, UserMovies userMovies)
        {
            var connection = new SqlConnection(connectionString);
            connection.Open();
            connection.ExecuteAsync(@"INSERT INTO UserMovies (Id,UserId,MovieId,Rating) VALUES (newid(),@UserId,@MovieId,@Rating)", new { userMovies.UserId, userMovies.MovieId, userMovies.Rating });
        }

        public static void VoteExisting(string connectionString,UserMovies userMovies)
        {
            var connection = new SqlConnection(connectionString);
            connection.Open();
            connection.ExecuteAsync(@"UPDATE UserMovies SET Rating = @Rating WHERE UserId = @UserId AND MovieId = @MovieId", new { userMovies.UserId, userMovies.MovieId, userMovies.Rating });
        }

    }
}
