﻿using Dapper;
using Dapper.Contrib.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace MovieApp.Entities
{
    public class User
    {
        public Guid? UserId { get; set; }

        [Required(ErrorMessage ="Name is required")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "Password is required")]
        public string Password { get; set; }

        public bool Active { get; set; }

        public string LastUpdatedBy { get; set; }

        public DateTime? LastupdatedOn { get; set; }


        //COMPUTED properties
        [Computed]
        [Write(false)]
        public int Rating { get; set; }

        [Computed]
        [Write(false)]
        public string MovieName { get; set; }

        public static IEnumerable<User> GetUsers(string connectionString)
        {
            using var connection = new SqlConnection(connectionString);
            connection.Open();
            return connection.Query<User>(@"SELECT * FROM Users");
        }

        public static void RegisterUser(string connectionString, User user)
        {
            using var connection = new SqlConnection(connectionString);
            connection.Open();
            //var query = @"INSERT INTO Users(UserName, Password) VALUES(@UserName, @Password)";
            var query = @"IF NOT EXISTS(SELECT UserId FROM Users WHERE UserName = @UserName AND Password = @Password) BEGIN INSERT INTO Users (UserName, Password) VALUES (@UserName, @Password) END";
            connection.ExecuteAsync(query, user);
        }

       
        public static bool LoginUser(string connectionString, User user)
        {
            using var connection = new SqlConnection(connectionString);
            connection.Open();
            var result = connection.QueryFirstOrDefault<bool>(@"SELECT 1 FROM Users WHERE UserName = @UserName AND Password = @Password",
                new { user.UserName, user.Password });
            return result;
        }
       
        public static Guid GetUserId(string connectionString, User user)
        {
            using var connection = new SqlConnection(connectionString);
            connection.Open();
            var result = connection.QueryFirstOrDefault<Guid>(@"SELECT UserId FROM Users WHERE UserName = @UserName AND Password = @Password",user);
            return result;
        }
       
        public static IEnumerable<User> GetUserDetails(string connectionString, Guid? userId)
        {
            var connection = new SqlConnection(connectionString);
            connection.Open();
            var query = @"SELECT Users.UserName,UserMovies.Rating,Movies.MovieName FROM Users INNER JOIN UserMovies ON Users.UserId = UserMovies.UserId INNER JOIN Movies ON UserMovies.MovieId = Movies.MovieId WHERE Users.UserId = @UserId;";
            return connection.Query<User>(query,new { UserId= userId } );
        }

        public static string GetUserNameById(string connectionString,Guid? userId)
        {
            var connection = new SqlConnection(connectionString);
            connection.Open();
            return connection.QueryFirstOrDefault<string>(@"SELECT UserName FROM Users WHERE UserId = @UserId", new { UserId = userId.Value });
        }
    }
}
