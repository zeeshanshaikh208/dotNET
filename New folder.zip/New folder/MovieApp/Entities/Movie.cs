﻿using Dapper;
using Dapper.Contrib.Extensions;
using Microsoft.Extensions.Configuration;
using MovieApp.Repository;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;

namespace MovieApp.Entities
{
    public class Movie
    {
        public Guid MovieId { get; set; }

        public string MovieName { get; set; }

        public bool Active { get; set; }

        public string LastUpdatedBy { get; set; }

        public DateTime? LastupdatedOn { get; set; }

        [Computed]        //annoted property will not be present in DB
        [Write(false)]
        public int Rating { get; set; }

        [Computed]
        [Write(false)]
        public int VotedBy { get; set; }


        public static IEnumerable<Movie> GetAllMovies(string connectionString)
        {
            using var connection = new SqlConnection(connectionString);
            connection.Open();         
            return connection.Query<Movie>(@"SELECT * FROM Movies");

        }

        public static IEnumerable<Movie> GetMovieRating(string connectionString)
        {
            using var connection = new SqlConnection(connectionString);
            connection.Open();
            var query = "SELECT Movies.MovieName,Movies.MovieId,AVG(Rating) AS Rating, COUNT(Rating) AS VotedBy FROM UserMovies RIGHT JOIN Movies ON Movies.MovieId = UserMovies.MovieId GROUP BY Movies.MovieName,Movies.MovieId ORDER BY Rating DESC";
            return connection.Query<Movie>(query);
        }

        public static string GetMovieNameById(string connectionString,Guid? movieId)
        {
            using var connection = new SqlConnection(connectionString);
            connection.Open();
            var result = connection.QueryFirstOrDefault<string>(@"SELECT MovieName FROM Movies WHERE MovieId = @MovieId", new { MovieId = movieId.Value });
            return result;
        }
        
    }
}
