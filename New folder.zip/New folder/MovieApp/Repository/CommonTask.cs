﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace MovieApp.Repository
{
    public class CommonTask : ICommonTask
    {
        private readonly IConfiguration configuration;

        public CommonTask(IConfiguration configuration)
        {
            this.configuration = configuration;
        }
        public string GetConnection()
        {
            return configuration.GetConnectionString("DefaultConnection");
        }

      
    }
}
